#ifndef __sg_element_c__
#define __sg_element_c__

#include "sg.h"

/* sg_element */

void sg_element_clear_over(sg_element *e) {
  sg_element* p;

  p = e;

  if (p->flags & SG_FLAG_OVER)
    p->flags -= SG_FLAG_OVER;

  while (NULL != p->over) {
    p = p->over;
    if (p->flags & SG_FLAG_OVER) {
      p->flags -= SG_FLAG_OVER;
    } else {
      return;
    }
  }
}

void sg_element_set_geo(sg_element *e, u_int x, u_int y, u_int w, u_int h) {
  e->geo->v[0] = x;
  e->geo->v[1] = y;
  e->geo->v[2] = w;
  e->geo->v[3] = h;
  return;
}

void sg_element_over(sg_element *e, vi2 *offset, vi2 *point) {
  llist *found;
  sg_element *e2;
  vi2* o;

  //printf("%x,%x,%x\n", e, offset, point);

  /*
  assert(NULL != e);
  assert(NULL != offset);
  assert(NULL != point);
  */

  //printf("over: [%d,%d] point [%d,%d]\n", offset->v[0], offset->v[1], point->v[0], point->v[1]);

  bool find(llist *l) {
    sg_element *e;
    e = (sg_element*) l->e;
    if ((point->v[0] >= e->geo->v[0] + offset->v[0]) &&
	(point->v[1] >= e->geo->v[1] + offset->v[1]) &&
	(point->v[0] <= e->geo->v[0] + offset->v[0] + e->geo->v[2]) &&
	(point->v[1] <= e->geo->v[1] + offset->v[1] + e->geo->v[3])) {
      return true;
    } else {
      return false;
    }
  }

  found = llist_find(e->children, find);

  if (NULL != found) {
    //printf("found over\n");

    e2 = (sg_element*) found->e;

    if ((e->over) && (e->over != e2)) {
      //printf("clearing old over\n");
      sg_element_clear_over(e->over);
    }

    o = vi2_new(offset->v[0] + e2->geo->v[0], offset->v[1] + e2->geo->v[1]);
    e2->flags |= SG_FLAG_OVER;
    sg_element_over(e2, o, point);

    vi2_del(o);

    e->over = e2;
  } else {
    //printf("not found\n");
    if (NULL != e->over) {
      sg_element_clear_over(e->over);
      e->over = false;
      //printf("clearing over\n");
    }
  }

  return;
}

/* end of sg_element */

#endif /* __sg_element_c__ */

