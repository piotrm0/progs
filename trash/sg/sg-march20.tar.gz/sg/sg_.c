#ifndef __sg__c__
#define __sg__c__

#include "sg.h"

#endif /* __sg__c__ */

