#ifndef __sg_element_window_c__
#define __sg_element_window_c__

#include "sg.h"

/* sg_window */

sg_window* sg_window_new(sg_root *root) {
  sg_window* ret;
  sg_window_head* head;

  ret = (sg_window*) malloc(sizeof(sg_window));

  ret->type = SG_TYPE_WINDOW;
  ret->parent = NULL;
  ret->focus  = NULL;
  ret->over   = NULL;
  ret->root   = root;
  ret->flags = SG_FLAG_NONE;

  ret->children = llist_new();

  ret->render  = (fun_render)  sg_window_render;
  ret->draw    = (fun_draw)    sg_window_draw;
  ret->set_geo = (fun_set_geo) sg_window_set_geo;

  ret->geo  = recti_new(0,0,0,0);

  head = sg_window_head_new(root);

  head->parent = (sg_element*) ret;

  ret->subs = (sg_element**) calloc(2, sizeof(sg_element*));

  ret->subs[SG_WINDOW_SUB_HEAD] = (sg_element*) head;
  ret->subs[SG_WINDOW_SUB_PANE] = NULL;

  llist_push(ret->children, (void*) head);

  return ret;
}

void sg_window_del(sg_window* e) {
  recti_del(e->geo);
  llist_free(e->children);
  free(e->subs);
  free(e);

  return;
}

void sg_window_render(sg_window* e, vi2* offset) {
  vi2 *o;

  sg_window_draw(e, offset);

  o = vi2_new(e->geo->v[0], e->geo->v[1]);
  sg_window_head_render((sg_window_head*) e->subs[SG_WINDOW_SUB_HEAD], o);
  vi2_del(o);

  return;
}

void sg_window_draw(sg_window* w, vi2* o) {
  u_int top,right,bottom,left;

  assert(NULL != w);
  assert(NULL != o);

  left   = w->geo->v[0] + o->v[0];
  bottom = w->geo->v[1] + w->geo->v[3] + o->v[1];
  right  = w->geo->v[0] + w->geo->v[2] + o->v[0];
  top    = w->geo->v[1] + o->v[1];

  //  glViewport(left, bottom, right-left, bottom-top);

  glBegin(GL_QUADS);
  glColor4f(1.0f, 0.0, 0.0, 0.5f);
  glVertex2i(left,  top);
  glVertex2i(right, top);
  glVertex2i(right, bottom);
  glVertex2i(left,  bottom);
  glEnd();

  glLineWidth(1.0f);
  if (w->flags & SG_FLAG_OVER) {
    glColor4f(1.0f, 1.0, 1.0, 1.0f);
  } else {
    glColor4f(1.0f, 0.0, 0.0, 1.0f);
  }

  glBegin(GL_LINE_LOOP);
  glVertex2i(left,  top);
  glVertex2i(right+1, top-1);
  glVertex2i(right, bottom);
  glVertex2i(left,  bottom);
  glEnd();

  return;
}

void sg_window_set_geo(sg_window *e, u_int x, u_int y, u_int w, u_int h) {
  sg_element_set_geo((sg_element*) e, x,y,w,h);
  sg_window_head_set_geo((sg_window_head*) e->subs[SG_WINDOW_SUB_HEAD], 0, 0, w, HEAD_HEIGHT);
}

sg_window_head* sg_window_head_new(sg_root *root) {
  sg_window_head *ret;
  sg_label *label;

  ret = (sg_window_head*) malloc(sizeof(sg_window_head));

  ret->type = SG_TYPE_WINDOW_HEAD;
  ret->parent = NULL;
  ret->focus  = NULL;
  ret->over   = NULL;
  ret->root   = root;
  ret->flags = SG_FLAG_NONE;

  ret->children = llist_new();

  ret->render  = (fun_render)  sg_window_head_render;
  ret->draw    = (fun_draw)    sg_window_head_draw;
  ret->set_geo = (fun_set_geo) sg_window_head_set_geo;

  ret->geo  = recti_new(0,0,0,0);

  label = sg_label_new(ret->root);

  ret->subs = (sg_element**) calloc(1, sizeof(sg_element*));
  ret->subs[SG_WINDOW_HEAD_SUB_LABEL] = (sg_element*) label;
  llist_push(ret->children, (void*) label);

  return ret;
}

void sg_window_head_render(sg_window_head* e, vi2* offset) {
  vi2 *o;

  sg_window_head_draw(e, offset);

  o = vi2_new(offset->v[0] + e->geo->v[0], offset->v[1] + e->geo->v[1]);
  sg_label_render((sg_label*) e->subs[SG_WINDOW_HEAD_SUB_LABEL], o);
  vi2_del(o);

  return;
}

void sg_window_head_draw(sg_window_head* e, vi2* o) {
  u_int top,right,bottom,left;

  assert(NULL != e);
  assert(NULL != o);

  left   = e->geo->v[0] + o->v[0];
  bottom = e->geo->v[1] + e->geo->v[3] + o->v[1];
  right  = e->geo->v[0] + e->geo->v[2] + o->v[0];
  top    = e->geo->v[1] + o->v[1];

  glBegin(GL_QUADS);
  glColor4f(1.0f, 0.0, 0.0, 0.5f);
  glVertex2i(left,  top);
  glVertex2i(right, top);
  glVertex2i(right, bottom);
  glVertex2i(left,  bottom);
  glEnd();

  glLineWidth(1.0f);
  if (e->flags & SG_FLAG_OVER) {
    glColor4f(1.0f, 1.0, 1.0, 1.0f);
  } else {
    glColor4f(1.0f, 0.0, 0.0, 1.0f);
  }

  glBegin(GL_LINE_LOOP);
  glVertex2i(left,  top);
  glVertex2i(right+1, top-1); // line join bug hack
  glVertex2i(right, bottom);
  glVertex2i(left,  bottom);
  glEnd();

  return;
}

void sg_window_head_set_geo(sg_window_head *e, u_int x, u_int y, u_int w, u_int h) {
  sg_element_set_geo((sg_element*) e, x,y,w,h);
  sg_element_set_geo(e->subs[SG_WINDOW_HEAD_SUB_LABEL], 20, 0, w - 80, h);
  //  sg_element_set_geo(e->subs[SG_WINDOW_HEAD_SUB_LABEL], 50, 50, 200, 200);
}

/* end of sg_window */

#endif /* __sg_element_window_c__ */

