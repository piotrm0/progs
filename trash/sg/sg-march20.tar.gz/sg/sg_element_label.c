#ifndef __sg_element_label_c__
#define __sg_element_label_c__

#include "sg.h"

/* sg_label */

sg_label* sg_label_new(sg_root *root) {
  sg_label* ret;

  ret = (sg_label*) malloc(sizeof(sg_label));

  ret->type = SG_TYPE_LABEL;
  ret->parent = NULL;
  ret->focus  = NULL;
  ret->over   = NULL;
  ret->root   = root;
  ret->flags = SG_FLAG_NONE;

  ret->children = llist_new();

  ret->render  = (fun_render)  sg_label_render;
  ret->draw    = (fun_draw)    sg_label_draw;
  ret->set_geo = (fun_set_geo) sg_label_set_geo;

  ret->geo  = recti_new(0,0,0,0);

  ret->string = NULL;

  return ret;
}

void sg_label_render(sg_label *e, vi2 *offset) {
  sg_label_draw(e, offset);

  return;
}

void sg_label_draw(sg_label *e, vi2 *o) {
  u_int top,right,bottom,left;
  vi2* o2;

  assert(NULL != e);
  assert(NULL != o);

  left   = e->geo->v[0] + o->v[0];
  bottom = e->geo->v[1] + e->geo->v[3] + o->v[1];
  right  = e->geo->v[0] + e->geo->v[2] + o->v[0];
  top    = e->geo->v[1] + o->v[1];

  glBegin(GL_QUADS);
  glColor4f(1.0f, 0.0, 0.0, 0.5f);
  glVertex2i(left,  top);
  glVertex2i(right, top);
  glVertex2i(right, bottom);
  glVertex2i(left,  bottom);
  glEnd();

  o2 = vi2_copy(o);
  o2->v[0] += e->geo->v[0];
  o2->v[1] += e->geo->v[1];

  glEnable(GL_SCISSOR_TEST);
  glScissor(left, 480 - bottom, e->geo->v[2], e->geo->v[3]);

  sg_type_draw(e->text, o2);

  glDisable(GL_SCISSOR_TEST);

  vi2_del(o2);

  glLineWidth(1.0f);
  if (e->flags & SG_FLAG_OVER) {
    glColor4f(1.0f, 1.0, 1.0, 1.0f);
  } else {
    glColor4f(1.0f, 0.0, 0.0, 1.0f);
  }

  glBegin(GL_LINE_LOOP);
  glVertex2i(left,  top);
  glVertex2i(right+1, top-1); // line join bug hack
  glVertex2i(right, bottom);
  glVertex2i(left,  bottom);
  glEnd();

  return;
}

void sg_label_set_geo(sg_label *e, u_int x, u_int y, u_int w, u_int h) {
  sg_element_set_geo((sg_element*) e, x,y,w,h);
}

void sg_label_set_string(sg_label *e, char* string) {
  u_int len;
  
  if (NULL != e->string)
    free(e->string);

  len = strlen(string);

  e->string = (char*) calloc(len, sizeof(char));

  memcpy(e->string, string, len);

  e->text = sg_type_new_render(e->root->font, string);
}

/* end of sg_label */

#endif /* __sg_element_label_c__ */

