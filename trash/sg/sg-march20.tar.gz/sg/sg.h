#ifndef __sg_h__
#define __sg_h__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <SDL/SDL.h>
#include <SDL/SDL_opengl.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include "list.h"
#include "util.h"
#include "m_util.h"

#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

#define HEAD_HEIGHT 20

#define SG_TYPE_ROOT   1
#define SG_TYPE_WINDOW 2
#define SG_TYPE_WINDOW_HEAD 3
#define SG_TYPE_PANE  4
#define SG_TYPE_LABEL 5

#define SG_FLAG_NONE  0
#define SG_FLAG_OVER  1
#define SG_FLAG_FOCUS 2

#define SG_WINDOW_SUB_HEAD       0
#define SG_WINDOW_SUB_PANE       1
#define SG_WINDOW_HEAD_SUB_LABEL 2

#define SG_TARGET_FPS 30
#define SG_TICKS      30 // number of frame timings used in average for fps control

typedef struct sg_image sg_image;
typedef struct sg_font sg_font;
typedef struct sg_type sg_type;
typedef struct sg_timing sg_timing;

typedef struct sg_element sg_element;
  typedef struct sg_root sg_root;
  typedef struct sg_window sg_window;
    typedef struct sg_window_head sg_window_head;
  typedef struct sg_pane sg_pane;
  typedef struct sg_label sg_label;

struct sg_image {
  recti* geo;
  SDL_Surface* image;
  GLuint tid;
};

typedef void (*fun_timing_mark)(u_int from_start, u_int from_last); // timing from start, time

sg_image* sg_image_load(sg_root* root, char* filename);
GLuint sg_image_texture(sg_image *image);
void sg_image_draw(sg_image *e, vi2 *o);

struct sg_timing {
  float target_tpf; // target ticks per frame

  u_int elapsed_ticks;
  u_int abs_elapsed_ticks;

  u_int started_ticks;     // number of ticks at last mark
  u_int abs_started_ticks; // number of ticks at the start of timing

  ravg* tpf;
  ravg* fps;

  int delay; // delay in ticks used to keep tpf at target or near it

  fun_timing_mark callback_frame;
};

sg_timing* sg_timing_new();
void sg_timing_delay(sg_timing *t);
void sg_timing_mark(sg_timing *t);
void sg_timing_mark_callback(sg_timing *t);

struct sg_font {
  u_int ptsize;
  sg_root *root;
  TTF_Font *font;
};

sg_font* sg_font_load(sg_root *root, char *filename, u_int ptsize);

struct sg_type {
  sg_font *font;
  vi2 *size;
  v2 *rsize;
  char *string;
  GLuint tid;
};

sg_type* sg_type_new_render(sg_font *font, char *string);
void sg_type_set_string(sg_type *e, char *string);
void sg_type_draw(sg_type *e, vi2 *o);

typedef void (*fun_render)(sg_element*, vi2*);
typedef void (*fun_draw)(sg_element*, vi2*);
typedef void (*fun_over)(sg_element*, vi2*, vi2*);
typedef void (*fun_set_geo)(sg_element*, u_int, u_int, u_int, u_int);

struct sg_element { 
  u_int type;                  // type, one of SG_TYPE_x
  struct sg_element *parent;
  struct sg_element *focus;    // if a child has focus, that child
  struct sg_element *over;     // if a child has mouseover, that child
  sg_root *root; 
  u_int flags;
  recti *geo;           // geometry
  llist* children;      // list of children, see list.h, superset of subs below
  sg_element **subs;    // named children, also present in children above
                        //   names are of form SG_x_SUB_y

  fun_render  render;   // render function (draw element and render children)
  fun_draw    draw;     // draw function (draw element)
  fun_set_geo set_geo;  // set geometry (set geometry and that of children if applicable)
};

void sg_element_clear_over(sg_element *e);
void sg_element_set_geo(sg_element *e, u_int x, u_int y, u_int w, u_int h);
void sg_element_over(sg_element *e, vi2 *offset, vi2 *point);

struct sg_root { // extend sg_element
  u_int type;
  sg_element *parent;
  sg_element *focus;
  sg_element *over;
  sg_root *root;
  u_int flags;
  recti *geo;
  llist* children;
  sg_element **subs;
  fun_render  render;
  fun_draw    draw;
  fun_set_geo set_geo;

  vi2* mouse;

  sg_timing* timing;

  SDL_Surface* screen;
  sg_font*    font;
};

sg_root* _sg_root_new();
void sg_root_render(sg_root* r, vi2* offset);
void sg_root_draw(sg_root* r, vi2* offset);
void sg_root_add_window(sg_root* root, sg_window* w);
void sg_root_set_geo(sg_root *e, u_int x, u_int y, u_int w, u_int h);
void sg_root_over(sg_root *root, vi2 *offset, vi2 *point);

struct sg_window { // extend sg_element
  u_int type;
  sg_element *parent;
  sg_element *focus;
  sg_element *over;
  sg_root *root;
  u_int flags;
  recti *geo;
  llist* children;
  sg_element **subs;
  fun_render  render;
  fun_draw    draw;
  fun_set_geo set_geo;
};

sg_window* sg_window_new(sg_root *root);
void sg_window_del(sg_window* w);
void sg_window_render(sg_window* w, vi2* offset);
void sg_window_draw(sg_window* w, vi2* o);
void sg_window_set_geo(sg_window *e, u_int x, u_int y, u_int w, u_int h);

struct sg_window_head { // extend sg_element
  u_int type;
  sg_element *parent;
  sg_element *focus;
  sg_element *over;
  sg_root *root;
  u_int flags;
  recti *geo;
  llist* children;
  sg_element **subs;
  fun_render  render;
  fun_draw    draw;
  fun_set_geo set_geo;
};

sg_window_head* sg_window_head_new(sg_root *root);
void sg_window_head_render(sg_window_head *w, vi2 *offset);
void sg_window_head_draw(sg_window_head *w, vi2 *o);
void sg_window_head_set_geo(sg_window_head *e, u_int x, u_int y, u_int w, u_int h);

struct sg_label { // extend sg_element
  u_int type;
  sg_element *parent;
  sg_element *focus;
  sg_element *over;
  sg_root *root;
  u_int flags;
  recti *geo;
  llist* children;
  sg_element **subs;
  fun_render  render;
  fun_draw    draw;
  fun_set_geo set_geo;

  char *string;
  sg_type *text;
};

sg_label* sg_label_new(sg_root *root);
void sg_label_render(sg_label *e, vi2 *offset);
void sg_label_draw(sg_label *e, vi2 *o);
void sg_label_set_geo(sg_label *e, u_int x, u_int y, u_int w, u_int h);
void sg_label_set_string(sg_label *e, char* string);

sg_root* sg_init();
void sg_loop(sg_root *root);
u_int _sg_gl_init(sg_root *root);

/* misc for development only */

sg_image *temp;

/* end of misc */

#endif /* __sg_h__ */
