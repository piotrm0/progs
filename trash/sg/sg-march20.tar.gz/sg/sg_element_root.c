#ifndef __sg_element_root_c__
#define __sg_element_root_c__

#include "sg.h"

/* sg_root */

sg_root* _sg_root_new() {
  u_int flags;
  SDL_Surface* screen;
  sg_root* ret;

  flags = SDL_OPENGL;

  if (SDL_Init(SDL_INIT_VIDEO) != 0) {
    fprintf(stderr, "Unable to initialize SDL: %s\n", SDL_GetError());
    return NULL;
  }

  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
 
  screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, flags);
  if (!screen) {
    fprintf(stderr, "Unable to set video mode: %s\n", SDL_GetError());
    return NULL;
  }

  ret = (sg_root*) malloc(sizeof(sg_root));
  ret->type = SG_TYPE_ROOT;
  ret->screen   = screen;
  ret->children = llist_new();
  ret->parent = NULL;
  ret->focus  = NULL;
  ret->over   = NULL;
  ret->root   = ret;
  ret->flags  = SG_FLAG_NONE;
  ret->mouse = vi2_new(0,0);

  ret->timing = sg_timing_new();

  ret->geo = recti_new(0,0,SCREEN_WIDTH, SCREEN_HEIGHT);

  ret->render  = (fun_render)  sg_root_render;
  ret->draw    = (fun_draw)    sg_root_draw;
  ret->set_geo = (fun_set_geo) sg_root_set_geo;

  //  ret->font = sg_font_load(ret->root, "fonts/sfd/FreeSerif.ttf", 15);
  //  ret->font = sg_font_load(ret->root, "fonts/sfd/FreeMono.ttf", 15);
  ret->font = sg_font_load(ret->root, "fonts/zeimusu0.ttf", 20);

  return ret;
}

void sg_root_add_window(sg_root* root, sg_window* w) {
  assert(NULL != root);
  assert(NULL != w);

  llist_push(root->children, w);

  w->parent = (sg_element*) root;

  return;
}

void sg_root_draw(sg_root* r, vi2* o) {
  u_int left, bottom, right, top;

  assert(NULL != r);
  assert(NULL != o);

  left   = r->geo->v[0] + o->v[0];
  bottom = r->geo->v[1] + r->geo->v[3] + o->v[1];
  right  = r->geo->v[0] + r->geo->v[2] + o->v[0];
  top    = r->geo->v[1] + o->v[1];

  //glViewport(left, bottom, right-left, bottom-top);

  /*
  glBegin(GL_QUADS);

  glColor4f(1.0f, 1.0f, 1.0f, 0.5f);

  glVertex2i(left,  top);
  glVertex2i(right, top);
  glVertex2i(right, bottom);
  glVertex2i(left,  bottom);

  glEnd();
  */

}

void sg_root_draw_mouse(sg_root* r) {
  assert(NULL != r);

  glBegin(GL_LINES);

  glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

  glVertex2i(r->mouse->v[0], r->mouse->v[1]-10);
  glVertex2i(r->mouse->v[0], r->mouse->v[1]+10);
  glVertex2i(r->mouse->v[0]-10, r->mouse->v[1]);
  glVertex2i(r->mouse->v[0]+10, r->mouse->v[1]);

  glEnd();
}

void sg_root_render(sg_root* root, vi2* o) {
  vi2* offset;

  offset = vi2_new(0,0);

  //  sg_image_draw(temp, (vi2*) &vi2_0);

  sg_root_draw(root, o);

  void render(llist *l) {
    sg_element* e;
    e = (sg_element*) l->e;
    e->render(e, offset);
  }

  llist_apply(root->children, render);

  sg_root_draw_mouse(root);

  return;
}

void sg_root_over(sg_root *root, vi2 *offset, vi2 *point) {
  sg_element_over((sg_element*) root, offset, point);

  return;
}

void sg_root_set_geo(sg_root *e, u_int x, u_int y, u_int w, u_int h) {
  sg_element_set_geo((sg_element*) e, x,y,w,h);
}

/* end of sg_root */

#endif /* __sg_element_root_c__ */

