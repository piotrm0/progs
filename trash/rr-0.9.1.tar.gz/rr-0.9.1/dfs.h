#ifndef __dfs_h__
#define __dfs_h__

#include "board.h"
#include <time.h>
#include <stdio.h>
//#include <iostream>

#define null NULL

#define hash_size 2800733 // 17 x 19 x 23 x 29

#define CRAP_BITS 4
#define	SHIFT_MASK 0x7

#endif /* __dfs_h__ */
